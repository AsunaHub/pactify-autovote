from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time

driver = webdriver.Firefox()
driver.get("https://www.pactify.fr/votes")

username = driver.find_element_by_name("username")
username.send_keys("username")

vote_button = driver.find_element_by_xpath('//button[text()="Voter"]')
vote_button.click()

# Attendre la redirection
wait = WebDriverWait(driver, 20)
continue_link = wait.until(EC.element_to_be_clickable((By.LINK_TEXT, 'Continuer')))
continue_link.click()

# Attendre 20 secondes
time.sleep(20)

# Cliquer sur "Clique ici pour continuer..."
continue_link = driver.find_element_by_link_text("Clique ici pour continuer...")
continue_link.click()

# Insérer le Captcha (reCaptcha)
# ...

# Cliquer sur le bouton "Voter" une fois le Captcha est terminé
vote_button = driver.find_element_by_xpath('//button[text()="Voter"]')
vote_button.click()

# Revenir sur la page "https://www.pactify.fr/votes"
driver.get("https://www.pactify.fr/votes")

# Cliquer sur le bouton "Recevoir ma récompense"
reward_button = driver.find_element_by_xpath('//button[text()="Recevoir ma récompense"]')
reward_button.click()

# Cliquer sur le bouton "Des Points VIP"
vip_points_button = driver.find_element_by_xpath('//button[text()="Des Points VIP"]')
vip_points_button.click()

driver.quit()

# Asuka#6565